export class Pregledinekretnina{
    id: number
    korisnickoime: string
    datum: string
}