export class Arhivirani{
    korisnickoime1: string
    id: number
}