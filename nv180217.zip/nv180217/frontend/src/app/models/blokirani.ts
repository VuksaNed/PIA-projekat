export class Blokirani{
    korisnickoime1: string
    korisnickoime2: string
}