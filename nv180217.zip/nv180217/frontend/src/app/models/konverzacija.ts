export class Konverzacija{
    text: string
    posiljalac: string
    vreme: string
    vremeuformatuzaispit: string
    posiljalaczaispit: string
    procitano: boolean
}