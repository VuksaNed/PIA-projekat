export class Ponuda{
    id: number
    datumOd: string
    datumDo: string
    posiljalac: string
    cena: number
    status:string
    vlasnik: string
    nazivnekretnine: string
    prodaja: boolean
    profitagencije: number
}