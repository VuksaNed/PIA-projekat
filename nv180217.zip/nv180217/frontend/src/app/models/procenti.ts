export class Procenti{
    prodaja: number
    iznajmljivanje:number
}