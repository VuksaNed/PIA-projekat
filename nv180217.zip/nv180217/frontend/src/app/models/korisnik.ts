export class Korisnik{
    ime: string
    prezime: string
    korisnickoime: string
    lozinka: string
    slika: string
    adresaeposte: string
    grad: string
    drzava: string
    tip: string
    status: string
}