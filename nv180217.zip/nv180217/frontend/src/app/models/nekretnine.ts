export class Nekretnina{
    naziv: string
    grad: string
    opstina: string
    ulica: string
    kucailistan: string
    brojspratova: number
    sprat: string
    kvadratura: number
    brojsoba: number
    namesten: boolean
    galerija : string[]
    prodaja: boolean
    cena: number
    vlasnik : string
    promovisana : boolean
    slikazaprikaz: string
    kucaspratnost: string
    tekstprodaje: string
    id: number
}